<?php

    // Ruta de la aplicacion
    define('RUTA_APP', dirname(dirname(__FILE__)));

    // Ruta url, Ejemplo: http://localhost/daw2_mvc
    define('RUTA_URL', 'https://192.168.4.165');

    define('NOMBRE_SITIO', 'CRUD MVC - DAW2 Alcañiz');


    // Configuracion de la Base de Datos
    define('DB_HOST', 'localhost');
    define('DB_USUARIO', 'pma');
    define('DB_PASSWORD', 'kamisama123');
    define('DB_NOMBRE', 'crud_mvc');
